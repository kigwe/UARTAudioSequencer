from uart_audio_sequencer import *

# visual.py
#
#     Author: Kelechi Igwe
#     Purpose: visual.py is the GUI module that contains the different
#              Tkinter functions and objects used for the GUI of the
#              UART Audio Sequencer.


def addEmptySpace():
    # Adds a space (line of nothing) in the window

    empty_space_label = Label(window, bg="white")
    empty_space_label.pack()


def popup_message(title, msg):
    # Given a window title (title) and a popup message (msg), this function
    # creates a small window to display a popup message.

    pup = Tk()  # Build window

    pup.title(title)
    pup.geometry("{}x{}".format(POPUP_WIDTH, POPUP_HEIGHT))  # Window size

    p_label = Label(pup, text=msg, font="none 10")  # Add message
    p_label.pack()

    pup.mainloop()  # Start showing window


def menu_bar(screen):
    # Given the current screen that is showing (screen), this function
    # builds a menu bar in the Tkinter window with options relevant
    # to the screen

    menubar = Menu(window)  # Build a menu bar

    if (screen == 'start'):  # Start Screen (Asks for Port Name and Baudrate)
        # Create 'Options' menu option that allows user to exit program
        options = Menu(menubar, tearoff=0)
        options.add_command(label='Exit', command=lambda: window.quit())
        menubar.add_cascade(label="Options", menu=options)

        # Create 'Help' menu option that provides pop-up message help for
        # questions regarding what the port name is and what the baud rate is
        helpmenu = Menu(menubar, tearoff=0)
        helpmenu.add_command(label='What is Port Name?',
                             command=lambda: help_with("pn"))
        helpmenu.add_command(label='What is Baud Rate?',
                             command=lambda: help_with("bd"))
        menubar.add_cascade(label="Help", menu=helpmenu)

        window.config(menu=menubar)  # Add menu bar to window

    elif (screen == 'sequencer'):  # Sequencer Screen (Where User Adds Notes)
        # Create 'Options' menu option that allows user to either Close Port
        # so that they could go back to starting screen or Exit to exit
        # program
        options = Menu(menubar, tearoff=0)
        options.add_command(label='Close Port', command=lambda: close_port())
        options.add_command(label='Exit', command=lambda: window.quit())
        menubar.add_cascade(label="Options", menu=options)

        # Create 'Load' menu option that allows user to build a sequence
        # hard-coded into program
        loadmenu = Menu(menubar, tearoff=0)
        loadmenu.add_command(label='C Major Scale',
                             command=lambda: add_sequence(0))
        loadmenu.add_command(label='C Chromatic Scale',
                             command=lambda: add_sequence(1))
        loadmenu.add_command(label='Heart and Soul',
                             command=lambda: add_sequence(2))
        loadmenu.add_command(label='Pomps and Circumstances',
                             command=lambda: add_sequence(3))
        menubar.add_cascade(label="Load", menu=loadmenu)

        window.config(menu=menubar)  # Add menu bar to window


def clear_screen():
    # Clears the current screen being shown by deleting all of the widgets
    # that have been packed into the window.

    w_list = window.winfo_children()

    for elem in w_list:
        if elem.winfo_children():
            w_list.extend(elem.winfo_children())

    for i in w_list:
        i.pack_forget()


def build_start_screen():
    # Builds the Tkinter widgets for the start of the program screen

    clear_screen()

    # Initialize Window
    window.title("UART Audio Sequencer")
    window.configure(background="white")
    window.geometry("{}x{}".format(START_WIDTH, START_HEIGHT))

    menu_bar("start")  # Build the menu bar for the start screen

    # Title
    title_label = Label(window, text="UART Audio Sequencer", bg="white",
                        fg="black", font="none 30 bold")
    title_label.pack()

    # Authors
    author_label = Label(window, text=AUTHOR_TAG, bg="white", fg="black",
                         font="none 16 bold")
    author_label.pack()
    for i in range(SEVEN_EMPTY_SPACES):
        addEmptySpace()

    # Ask for Port & Baud Rate
    port_name_label = Label(window, text="Enter Port Name", bg="white",
                            fg="black", font="none 14 bold")
    port_name_label.pack()
    port_name_entry = Entry(window, width=20, bg="white")
    port_name_entry.pack()
    addEmptySpace()

    baud_rate_label = Label(window, text="Enter Baudrate", bg="white",
                            fg="black", font="none 14 bold")
    baud_rate_label.pack()
    baud_rate_entry = Entry(window, width=20, bg="white")
    baud_rate_entry.pack()
    addEmptySpace()

    # Connect Button (Attempts to connect the port described by port name)
    connectButton = Button(window, text="Connect", fg="black", bg="yellow",
                    command=lambda: setup_uart(port_name_entry.get().strip(),
                                               baud_rate_entry.get().strip()))
    connectButton.pack()


def setup_window():
    build_start_screen()  # Prompt user to enter port name and baud rate

    window.mainloop()  # Start the program


def build_music_screen():
    clear_screen()  # Clear the screen

    menu_bar("sequencer")  # Build the menu bar for the sequencer screen

    # Title
    title_label = Label(window, text="UART Audio Sequencer", bg="white",
                        fg="black", font="none 30 bold")
    title_label.pack()

    # Authors
    author_label = Label(window, text=AUTHOR_TAG, bg="white", fg="black",
                         font="none 16 bold")
    author_label.pack()
    addEmptySpace()

    # Note Name, Octave, & Duration
    note_name_label = Label(window, text="Note Name", bg="white",
                            fg="black", font="none 14 bold")
    note_name_label.pack()
    note_name_entry = Entry(window, width=10, bg="white")
    note_name_entry.pack()
    addEmptySpace()

    note_octave_label = Label(window, text="Octave", bg="white",
                                fg="black", font="none 14 bold")
    note_octave_label.pack()
    note_octave_entry = Entry(window, width=10, bg="white")
    note_octave_entry.pack()
    addEmptySpace()

    note_duration_label = Label(window, text="Duration", bg="white",
                                fg="black", font="none 14 bold")
    note_duration_label.pack()
    note_duration_entry = Entry(window, width=10, bg="white")
    note_duration_entry.pack()

    units_label = Label(window, text=("(in eighths. Ex: Half Note is" +
                                     " 4 eights, so put 4 above.)"),
                        bg="white", fg="black", font="none 10 bold")
    units_label.pack()
    addEmptySpace()

    # Add Note Button (Attempts to add note to sequence)
    addNoteButton = Button(window, text="Add Note", bg="green", fg="white",
                    command=lambda: add_note(note_name_entry.get().strip(),
                                    note_octave_entry.get().strip(),
                                    note_duration_entry.get().strip()))
    addNoteButton.pack()

    addRestButton = Button(window, text="Add Rest", bg="yellow", fg="black",
                    command=lambda: add_note("rest", 3,
                                    note_duration_entry.get().strip()))
    addRestButton.pack()

    # Remove Note Button (Attempts to remove note from sequence)
    removeNoteButton = Button(window, text="Remove Note", bg="red",
                              fg="white", command=lambda: remove_note())
    removeNoteButton.pack()

    # Clear Notes Button (Attempts to remove all notes from sequence)
    clearNotesButton = Button(window, text="Clear Notes", bg="black",
                              fg="white", command=lambda: clear_notes())
    clearNotesButton.pack()

    addEmptySpace()  # For visual purposes

    # Play Notes Once Button (Attempts to send sequence through port)
    sendNotesButtonOne = Button(window, text="Play Notes Once", bg="orange",
                                fg="white", command=lambda: send_notes('O'))
    sendNotesButtonOne.pack()

    # Loop Notes Button (Attempts to send sequence through port)
    sendNotesButtonTwo = Button(window, text="Loop Notes", bg="purple",
                                fg="white", command=lambda: send_notes('L'))
    sendNotesButtonTwo.pack()

    addEmptySpace()  # Separation between button and notes
    addEmptySpace()


def notify_uart_setup():
    # When the program has successfully connected to the desired port, this
    # function notifies the user and then adds button to screen to allow
    # user to start building the note sequence

    connected_label = Label(window, text="Connected successfully!",
                            bg="white", fg="green", font="none 14 underline")
    connected_label.pack()

    addEmptySpace()

    continueButton = Button(window, text="Start Creating!", bg="blue",
                            fg="white", command=lambda: build_music_screen())
    continueButton.pack()


def show_notes(s):
    # Given a single string that contains all of the notes in the sequence in
    # note-duration format, this function displays all of the notes onto the
    # screen below the buttons.

    notes = False  # Boolean to detect whether there are notes already showing

    # =========Removes only the notes on the sequencer screen (if applicable)
    w_list = window.winfo_children()

    for elem in w_list:
        if elem.winfo_children():
            w_list.extend(elem.winfo_children())

    for item in w_list:
        if isinstance(item, Label):
            notes = item

    if notes:
        notes.pack_forget()
    # ========================================================================

    notes_label = Label(window, text=s, bg="white", fg="black",
                        font="none 9 bold")
    notes_label.pack()
