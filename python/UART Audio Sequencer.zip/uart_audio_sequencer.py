import visual
from uart import *
from uas import *
from tkinter import messagebox


# uart_audio_sequencer.py
#
#     Author: Kelechi Igwe
#     Purpose: uart_audio_sequencer.py is the wrapper file that contains
#              the main function for the UART Audio Sequencer, along with
#              other functions that use both Tkinter and PySerial functions.


def setup_uart(port_name, baud_rate):
    # Using the port name and baud rate entered in the start screen,
    # uses pyserial library to open desired port.

    if port_name == '' or baud_rate == '':  # If nothing was typed in a field
        messagebox.showwarning("Error",
        "Must enter data into both fields.")
        return

    # List of baud rates the UART Audio Sequencer accepts (based on MSP432)
    possible_br = [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200]

    if int(baud_rate) not in possible_br:
        messagebox.showwarning("Error",
        "Baud Rate must be one of the following: {}".format(possible_br))
        return

    err = init_Port(port_name, int(baud_rate))  # Attempt to open the port

    if err != 1:  # Error occurred when trying to open desired port
        messagebox.showwarning("Error",
        "Unable to open Port '{}'.\nConsole Message: '{}'".format(port_name,
                                                                  err))
        return

    visual.notify_uart_setup()  # If successfully opened port, tell user


def close_port():
    # Closes the current port being used to transfer data to microcontroller.

    close_Serial()
    note_list.clear()

    visual.build_start_screen()  # Go back to the starting screen


def help_with(name):
    # Given a two character string (name) describing the help message, this
    # builds the title of the popup message and the message itself, and then
    # calls a visual function to display that popup message

    title = ""  # Title of the Window
    msg = ""  # Message to be displayed

    if name == 'pn':  # Port Name Help
        title = 'Port Name Help'

        msg = "1) Open Device Manager (or wherever a list of\ndevices " + \
        "connected to your computer can be found).\n\n2) Look for device " + \
        "you plan to send\nsequence to (if using MSP432P401R, the name\n" + \
        "will be XDS110 Class Application/User UART).\n\n3) Put the port " + \
        "name into the entry box in this\nprogram (For the MSP432, it " + \
        "will be \nsomething like 'COM1' or 'COM8')."

    elif name == 'bd':  # Baud Rate Help
        title = 'Baud Rate'

        msg = "Baud rate is the speed at which bits are\ntransferred " + \
        "during a UART transfer. For our\nproject, the baud rate is 9600." + \
        " However, if you want to\nslow down or speed up the baud rate, " + \
        "make sure\nthat you use a baud rate accepted by this\nprogram " + \
        "and that the baud rate of this program\nmatches the baud " + \
        "rate of the device you are\nsending data to over UART."

    visual.popup_message(title, msg)  # Display message

def display_notes():
    # Given the current list of notes in transfer format (see add_note),
    # builds one string containing all of the notes into a note-duration
    # format and then display those notes onto the screen.
    # (Ex: ['B', 'b', '3', '4'] -> 'Bb3(1/2)')

    n_str = []
    counter = 0

    for i in range(0, len(note_list), NOTE_SIZE_IN_ARRAY):
        note = note_list[i]  # Note name (base)
        tone = note_list[i+1]  # Note variation (# - sharp, b - flat)
        octv = note_list[i+2]  # Note octave (between 2-5)
        dur = note_list[i+3]  # Duration of the note (in units 1/8)

        if note == '_':  # If a break note
            n_str.append("Rest")
        else:
            n_str.append(note)

        if tone != '_':  # If there is a variation
            n_str.append(tone)

        if note != '_':
            n_str.append(octv)
        n_str.append(' (')

        # For better readability, fractions are simplified
        if dur == '2':
            n_str.append("1/4")
        elif dur == '4':
            n_str.append("1/2")
        elif dur == '6':
            n_str.append("3/4")
        elif dur == '8':
            n_str.append("1")
        else:
            n_str.append("{}/8".format(dur))
        n_str.append('), ')  # End parentheses

        counter += 1
        if (counter % 10) == 0:  # Display maximum 10 notes per line
            counter = 0
            n_str.append('\n')

    visual.show_notes("".join(n_str))


def add_note(name, octv, duration, show=True):
    # Given the name of the note entered and the duration of the note
    # entered, add new note into sequence by converting to transfer format:
    # Note Name Base, Note Variation (sharp or flat), Note Octave (2-5), and
    # Duration (in eighths). If show is True, after the node is added to
    # sequence, display the new sequence on the screen.

    if (name == '') or (octv == '') or (duration == ''):
        # If one of the fields were empty
        messagebox.showwarning("Error",
        "Must enter data into both fields.")
        return

    if isinstance(octv, str):
        if not octv.isdigit():  # If octave or duration is not a digit
            messagebox.showwarning("Error",
            "Octave must be a positive value between {}-{}".format(MIN_OCTAVE,
                                                                MAX_OCTAVE))
            return
    if isinstance(duration, str):
        if not duration.isdigit():
            messagebox.showwarning("Error",
            "Octave must be a positive value between {}-{}".format(MIN_OCTAVE,
                                                                    MAX_OCTAVE))
            return

    conv_dict = dict()  # Conversion of enharmonics (Change all #s to bs)
    conv_dict['A'] = 'B'
    conv_dict['C'] = 'D'
    conv_dict['D'] = 'E'
    conv_dict['F'] = 'G'
    conv_dict['G'] = 'A'

    # Possible notes that can be entered by user (not case-sensitive). To
    # avoid debates, sharps and flats of same note (enharmonics) are included
    # but will be changed when stored into the sequence array.
    # (Ex: C# has same frequency as Db, but user can enter any of the two)
    # (Note: For a note that doesn't play anything, user will type in 'None')
    possible_notes = ['C', 'C#', 'Db', 'D', 'D#', 'Eb', 'E', 'F', 'F#', 'Gb',
                      'G', 'G#', 'Ab', 'A', 'A#', 'Bb', 'B', 'Rest']

    n_len = len(name)
    if (n_len == 2):  # If note is a flat or a sharp
        n = name[0].upper() + name[1].lower()
        if n[1] == '#':
            n = conv_dict.get(n[0]) + 'b'
    elif (name.upper() == 'REST'):  # If note is a rest note.
        n = 'Rest'
    else:
        n = name.upper()

    if n == 'Rest':
        o = 3
    else:
        o = int(octv)  # Convert user input to integer (only for function)

    d = int(duration)  # Convert user input to integer (only for function)

    if (o < MIN_OCTAVE) or (o > MAX_OCTAVE):  # If octave not valid
        messagebox.showwarning("Error",
        "Octave must be a positive value between {}-{}".format(MIN_OCTAVE,
                                                                MAX_OCTAVE))
        return
    elif (d < MIN_DURATION) or (d > MAX_DURATION):  # If duration not valid
        messagebox.showwarning("Error",
        "Duration must be a positive value between {}-{}".format(MIN_DURATION,
                                                                 MAX_DURATION))
        return
    elif ((n_len < 1) or (n_len > 2)) and (n != "Rest"):  # Invalid note check
        messagebox.showwarning("Error",
        "Note is either 1 character, 2 characters, or the word 'Rest'")
        return
    elif n not in possible_notes:  # Invalid note check 2
        messagebox.showwarning("Error",
        "Note invalid (Possible Notes: {}.".format(possible_notes))
        return
    elif (n[0] == 'B' and o == 5) or \
         (n[0] in ['G', 'F', 'E', 'D', 'C'] and o == 2):  # Note not in A2-A5
        messagebox.showwarning("Error",
        "Note invalid (Notes must be in between A2 and A5)")
        return
    # If the the length of the sequence is filled to capacity
    elif len(note_list) > (MAX_NOTES_IN_SEQUENCE * NOTE_SIZE_IN_ARRAY):
        messagebox.showwarning("Error",
        "Maximum number of notes have been recorded ({}).\
         Send then clear notes or remove note.".format(MAX_NOTES_IN_SEQUENCE))
        return

    if n == 'Rest':
        note_list.append('_')  # '_' is the character repr. of a silent note
        note_list.append('_')
    else:
        note_list.append(n[0])
        if (n_len == 2):
            note_list.append(n[1])
        else:
            note_list.append('_')  # '_' also means no flat/sharp variation

    note_list.append(str(o))  # Convert int(octave) to char
    note_list.append(str(d))  # Convert int(duration) to char

    if show:  # If function call wants to display sequence after each add note
        display_notes()


def add_sequence(seq):
    # Given a sequence number (seq), this function clears the current list of
    # notes and builds a pre-defined list of notes from below.

    all_notes = []  # List containing all the notes in the sequence
    all_octv = []  # List containing all the octaves of each note in sequence
    all_dur = []  # List containing the durations of each note in the sequence

    if note_list:  # If there was already a sequence loaded before, clear it
        clear_notes()

    if seq == 0:  # Build C Major Scale
        notes = ['C', 'D', 'E', 'F', 'G', 'A', 'B', 'C']

        # List of above notes and them backwards (excluding last element)
        all_notes = notes + notes[-2::-1]
        all_octv = ([4] * 7) + [5] + ([4] * 7)
        all_dur = [2] * MAJOR_SCALE_LENGTH  # Scale played in 1/4 notes

    elif seq == 1:  # Build C Chromatic Scale
        notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'Bb',
                 'B', 'C']

        # List of above notes and them backwards (excluding last element)
        all_notes = notes + notes[-2::-1]
        all_octv = ([4] * 12) + [5] + ([4] * 12)
        all_dur = [2] * CHROMATIC_SCALE_LENGTH  # Scale played in 1/4 notes

    elif seq == 2:  # Heart & Soul
        all_notes = ['F', 'F', 'F', 'Rest', 'F', 'E', 'D', 'E', 'F', 'G',
                     'A', 'A', 'A', 'Rest', 'A', 'G', 'F', 'G', 'A',
                     'Bb', 'C', 'F', 'Rest', 'D', 'C', 'Bb',
                     'A', 'G', 'F', 'E', 'D', 'C',
                     'Bb', 'Bb', 'C', 'Rest', 'C', 'Rest']
        all_octv = ([4] * 20) + [5] + [4, 4] + [5, 5] + ([4] * 7) + \
                   [3, 3] + ([4] * 2) + [5] + [4]
        all_dur = [2, 2, 4, 1, 1, 1, 1, 1, 1, 2, 2, 2, 4, 1, 1, 1, 1, 1, 1,
                   2, 4, 4, 1, 1, 1, 1, 2, 2, 3, 1, 3, 1, 3, 1, 1, 1, 1, 1]

    elif seq == 3:  # Pomps and Circumstances
        notes = ['C', 'B', 'C', 'D', 'A', 'G', 'F', 'E', 'F', 'G', 'D',
                     'Rest', 'E', 'Gb', 'G', 'A', 'D', 'G', 'Rest', 'C', 'C',
                     'B', 'A', 'G', 'D']
        all_notes = notes + notes[:19] + ['F', 'F', 'E', 'D', 'E', 'Rest']
        octvs = [5] + [4] + ([5] * 2) + ([4] * 12) + [5] + [4] + [4] + \
                   ([5] * 2) + ([4] * 4)
        all_octv = octvs + octvs[:19] + ([5] * 6)
        durs = [4, 1, 1, 2, 4, 4, 4, 1, 1, 2, 7, 1, 4, 1, 1, 2, 4, 3, 1,
                   4, 1, 1, 2, 6, 2]
        all_dur = durs + durs

    for i in range(len(all_notes)):
        # Add each note from the all_notes and all_dur banks but don't call
        # display_notes() after each note to improve efficiency
        add_note(all_notes[i], all_octv[i], all_dur[i], False)

    display_notes()  # Show notes on screen


def remove_note():
    # Removes the last note of the sequence and then displays new sequence
    # on the screen.

    if note_list == []:  # Empty sequence check
        messagebox.showwarning("Error",
        "There are no notes to remove.")
        return

    for i in range(NOTE_SIZE_IN_ARRAY):  # Remove entire note from list
        note_list.pop()

    display_notes()


def clear_notes():
    # Removes all of the notes in the sequence and then clears the notes
    # from the screen.

    if note_list == []:  # Empty sequence check
        messagebox.showwarning("Error",
        "There are no notes to clear.")
        return

    note_list.clear()
    display_notes()


def send_notes(c):
    # Given a character (c) defining whether the sequence should play once
    # or indefinitely, send the note sequence (note_list) character by
    # character over the opened device port with the sequence in transfer
    # format:
    # ['*', length of notes in character by character, note_list, c].
    # (Ex: ['*', '2', '_', 'A', 'b', '2, 'C', 'n', '6', 'L'] will be what
    # is transferred for a sequence of length 2 with Ab for 1/4 duration
    # and C for 3/4 duration that loops indefinitely)

    if note_list == []:  # Empty Sequence Check
        messagebox.showwarning("Error",
        "There are no notes to send.")
        return

    # Get length of sequence (number of notes only) and convert to string
    num_notes = str(int(len(note_list) / NOTE_SIZE_IN_ARRAY))

    transmit(bytes('*', ENCODE))  # Start character

    for i in num_notes:
        transmit(bytes(i, ENCODE))

    transmit(bytes('_', ENCODE))  # End of sequence length character

    for note_prop in note_list:  # Transmit each note property in order
        transmit(bytes(note_prop, ENCODE))

    # End transfer by sending 'L'-loop or 'O'-play once
    transmit(bytes(c, ENCODE))


def main():
    visual.setup_window()  # Build start screen


if __name__ == "__main__":
    main()