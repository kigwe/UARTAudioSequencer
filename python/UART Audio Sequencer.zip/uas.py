from tkinter import *

# uas.py
#
#     Author: Kelechi Igwe
#     Purpose: uas.py is the variable file that contains all of the
#              global variables and macros used throughout the UART
#              Audio Sequencer.

# Macros
#     Geometry Macros
START_WIDTH = 640  # Window width
START_HEIGHT = 640  # Window height
POPUP_WIDTH = int(START_WIDTH / 2)  # Popup window width
POPUP_HEIGHT = int(START_HEIGHT / 2)  # Popup window height

#     Spacing Macros
FOUR_EMPTY_SPACES = 4
SEVEN_EMPTY_SPACES = 7

#     Sequence Macros
MAX_NOTES_IN_SEQUENCE = 256  # Maximum number of notes in sequence
NOTE_SIZE_IN_ARRAY = 4  # Number of array elements used to define a note
MIN_OCTAVE = 2  # Minimum octave that can be played by program
MAX_OCTAVE = 5  # Maximum octave that can be played by program
MIN_DURATION = 1  # Minimum duration of a note (in units 1/8s)
MAX_DURATION = 9  # Maximum duration of a note (in units 1/8s)

#     Other Macros
ENCODE = 'utf-8'  # Encoder for characters in bytes() function
AUTHOR_TAG = "By Kelechi Igwe, Brandon Nowak, Reed Slobodin"  # Project Membrs
MAJOR_SCALE_LENGTH = 15  # Number of notes in the major scale sequence
CHROMATIC_SCALE_LENGTH = 25  # Number of notes in the chromatic scale sequence

# Global Variables
window = Tk()  # Tkinter window that holds widgets of program
note_list = []  # List containing all of the notes in the sequence