import serial

# uart.py
#
#     Author: Kelechi Igwe
#     Purpose: uart.py is the serial interfacing module that handles the
#              serial communication aspects of the UART Audio Sequencer,
#              from opening and closing ports to transmit characters.

#  Global Variable
serial_port = 0  # Serial instance used for sending data

#  File specific Macros
TIMEOUT_DELAY = 10  # Delay for port timeout

def init_Port(name, br):
    # Given a port name (name) and a baud rate (br), this function uses
    # the pySerial library to open the port for communication through
    # Python

    global serial_port

    try:  # Attempt to open the port
        serial_port = serial.Serial(name)
    except Exception as exc:  # If unable to open the port
        return "ERROR: " + repr(exc)

    serial_port.baudrate = br

    serial_port.timeout = TIMEOUT_DELAY  # To avoid port hanging in program

    return 1  # Port was successfully opened

def close_Serial():
    # Closes the port that was previously opened through init_Port function

    serial_port.close()

def transmit(b):
    # Given a byte (b), this function transmits the byte through the opened
    # serial port

    if not(isinstance(b, bytes)):  # Confirm b is a byte before transfer
        print("Transmit Failed")
        return False

    serial_port.write(b)

    return True


